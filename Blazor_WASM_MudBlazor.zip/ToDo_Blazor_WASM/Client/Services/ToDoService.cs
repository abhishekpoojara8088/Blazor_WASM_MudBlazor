﻿using ToDo_Blazor_WASM.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Json;

namespace ToDo_Blazor_WASM.Client.Services
{
    public class ToDoService : IToDoService
    {
        public List<ToDoItem> items { get; set; } = new List<ToDoItem>();
        private readonly HttpClient _httpClient;

        public ToDoService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<ToDoItem>> Get()
        {
            items = await _httpClient.GetFromJsonAsync<List<ToDoItem>>("api/ToDoItem");
            return items;
        }

        public ToDoItem Get(Guid ID)
        {
            return items.First(x => x.ID == ID);
        }

        public async Task<List<ToDoItem>> Add(ToDoItem toDoItem)
        {
            items.Add(toDoItem);
            var result =  _httpClient.PostAsJsonAsync($"api/ToDoItem", items);
            return items;
        }

        public List<ToDoItem> Toggle(Guid ID)
        {
            var toDoItemToUpdate = Get(ID);

            if (toDoItemToUpdate != null)
            {
                toDoItemToUpdate.IsComplete = !toDoItemToUpdate.IsComplete;
                var result = _httpClient.PostAsJsonAsync($"api/ToDoItem", items);
            }
            return items;
        }

        public List<ToDoItem> Delete(Guid ID)
        {
            var toDoItemToRemove = Get(ID);

            if (toDoItemToRemove != null)
            {
                items.Remove(Get(ID));
                var result = _httpClient.PostAsJsonAsync($"api/ToDoItem", items);
            }
            return items;
        }
    }
}


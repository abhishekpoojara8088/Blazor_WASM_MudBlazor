﻿using ToDo_Blazor_WASM.Shared;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ToDo_Blazor_WASM.Client.Services
{
    public interface IToDoService
    {
        Task<List<ToDoItem>> Get();
        ToDoItem Get(Guid ID);
        Task<List<ToDoItem>> Add(ToDoItem toDoItem);
        List<ToDoItem> Toggle(Guid id);
        List<ToDoItem> Delete(Guid ID);

    }
}

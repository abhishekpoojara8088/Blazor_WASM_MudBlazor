﻿using Microsoft.AspNetCore.Mvc;
using ToDo_Blazor_WASM.Shared;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace ToDo_Blazor_WASM.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToDoItemController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ToDoItemController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        private List<ToDoItem> _toDoItems;

        [HttpGet]
        public async  Task<List<ToDoItem>> GetToDoItems()
        {
            var json = System.IO.File.ReadAllText(_configuration["SampleDataFile"]);
            _toDoItems = JsonConvert.DeserializeObject<List<ToDoItem>>(json);
            return _toDoItems;
        }

        [HttpPost]
        public async Task<List<ToDoItem>> CreateToDoItems(List<ToDoItem> item)
        {
            string json = JsonConvert.SerializeObject(item);
            System.IO.File.WriteAllText(_configuration["SampleDataFile"], json);
            var jsonvalue = System.IO.File.ReadAllText(_configuration["SampleDataFile"]);
            _toDoItems = JsonConvert.DeserializeObject<List<ToDoItem>>(jsonvalue);
            return _toDoItems;
        }
    }
}
